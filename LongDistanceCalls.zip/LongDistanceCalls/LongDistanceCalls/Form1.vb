﻿'Written by Megan Beeson.
'June 21, 2016.
Option Strict On
Option Explicit On
Public Class Form1
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim intCalls As Integer
        Dim decTotal As Decimal
        Dim decBaseFee As Decimal
        Dim blnInputOk As Boolean = True

        'Contstants for Rate Catagories
        Const decDAYTIME_FEE As Decimal = 0.07D
        Const decEVENING_FEE As Decimal = 0.12D
        Const decOFFPEAK_FEE As Decimal = 0.05D

        'Validate Numeric
        lblStatus.Text = String.Empty
        If Integer.TryParse(txtMinutes.Text, intCalls) = False Then
            lblStatus.Text = "Calls must be an integer"
            blnInputOk = False
        End If

        'Validate Number of minutes.
        If intCalls <= 0 Then
            lblStatus.Text = "Calls must be greater than 0"
            blnInputOk = False
        End If

        If blnInputOk = True Then
            If radDaytime.Checked = True Then
                decBaseFee = decDAYTIME_FEE
            ElseIf radEvening.Checked = True Then
                decBaseFee = decEVENING_FEE
            ElseIf radOffPeak.Checked = True Then
                decBaseFee = decOFFPEAK_FEE
            End If

            'Calcualte the total fee.
            decTotal = decBaseFee * intCalls

            'Display the fees.
            lblTotalCost.Text = decTotal.ToString("c")
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Clear Radio Buttons.
        radDaytime.Checked = False
        radEvening.Checked = False
        radOffPeak.Checked = False

        'Clear Status Label.
        lblStatus.Text = String.Empty

        'Clear number of calls.
        txtMinutes.Clear()

        'Clear the total.
        lblTotalCost.Text = String.Empty

        'Give txtMinutes the focus.
        txtMinutes.Focus()

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'Close form
        Me.Close()
    End Sub
End Class